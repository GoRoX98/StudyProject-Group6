using UnityEngine;

public class Player : MonoBehaviour
{
    [SerializeField][Range(1,10)] private float _speed = 2f;
    private string _text = "Message";

    private Gameplay _gameplay;
    private float _timer = 0f;

    private void Awake()
    {
        _gameplay = new Gameplay(GetComponent<Rigidbody>());
    }

    void Update()
    {
        _timer += Time.deltaTime;
        if (_timer > 5f)
        {
            _timer = 0f;
            _gameplay.DoSomething();
        }

        var directionV = Input.GetAxis("Vertical");
        var directionH = Input.GetAxis("Horizontal");

        transform.position += (Vector3.forward * directionV + Vector3.right * directionH) * _speed * Time.deltaTime;
    }
}
